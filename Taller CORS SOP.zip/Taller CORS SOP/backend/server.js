const express = require('express');
const app = express();

// Configuración CORS - permitir acceso desde el frontend
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:5500');
    res.setHeader('Access-Control-Allow-Methods', 'GET');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

app.get('/api/datos', (req, res) => {
    res.json({ 
        mensaje: "Respuesta exitosa con CORS habilitado",
        fecha: new Date().toLocaleString()
    });
});

app.listen(3000, () => {
    console.log("Servidor con CORS corriendo en http://localhost:3000");
});