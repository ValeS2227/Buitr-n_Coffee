<?php
// ============================================================
//  BUITRON COFFEE — Registro de usuario
//  Archivo: php/registro.php
// ============================================================

session_start();
header("Content-Type: application/json");
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["exito" => false, "mensaje" => "Método no permitido"]);
    exit;
}

// Recoger y limpiar datos del formulario
$nombre    = trim($_POST["nombre"]    ?? "");
$apellido  = trim($_POST["apellido"]  ?? "");
$documento = trim($_POST["documento"] ?? "");
$telefono  = trim($_POST["telefono"]  ?? "");
$correo    = trim($_POST["correo"]    ?? "");
$password  = trim($_POST["password"]  ?? "");

// Validaciones básicas
if (empty($nombre) || empty($apellido) || empty($documento) || empty($telefono) || empty($correo) || empty($password)) {
    echo json_encode(["exito" => false, "mensaje" => "Por favor completa todos los campos"]);
    exit;
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["exito" => false, "mensaje" => "El correo no tiene un formato válido"]);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(["exito" => false, "mensaje" => "La contraseña debe tener al menos 6 caracteres"]);
    exit;
}

// Verificar si el correo ya existe
$stmt = $conexion->prepare("SELECT ID_Usuario FROM usuario WHERE Correo = ? OR Nombre_usuario = ? OR Documento = ?");
$stmt->bind_param("sss", $correo, $nombre, $documento);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(["exito" => false, "mensaje" => "El correo, usuario o documento ya está registrado"]);
    $stmt->close();
    exit;
}
$stmt->close();

// Encriptar contraseña con bcrypt
$clave_encriptada = password_hash($password, PASSWORD_BCRYPT);

// Insertar nuevo usuario con rol 2 = "Usuario"
$stmt = $conexion->prepare(
    "INSERT INTO usuario (Nombre_usuario, Apellido, Correo, Documento, Telefono, Clave, ID_Rol)
     VALUES (?, ?, ?, ?, ?, ?, 2)"
);
$stmt->bind_param("ssssss", $nombre, $apellido, $correo, $documento, $telefono, $clave_encriptada);

if ($stmt->execute()) {
    echo json_encode(["exito" => true, "mensaje" => "¡Registro exitoso! Ya puedes iniciar sesión"]);
} else {
    echo json_encode(["exito" => false, "mensaje" => "Error al registrar: " . $conexion->error]);
}

$stmt->close();
$conexion->close();
?>
