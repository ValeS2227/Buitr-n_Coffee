<?php
// ============================================================
//  BUITRON COFFEE — Obtener productos
//  Archivo: php/productos.php
// ============================================================

header("Content-Type: application/json");
require_once "conexion.php";

// Obtener todos los productos con stock disponible
$sql = "SELECT ID_Producto, Nombre_producto, Descripcion, Categoria, Precio, Stock
        FROM producto
        ORDER BY ID_Producto ASC";

$resultado = $conexion->query($sql);

if (!$resultado) {
    echo json_encode(["exito" => false, "mensaje" => "Error al obtener productos: " . $conexion->error]);
    exit;
}

$productos = [];
while ($fila = $resultado->fetch_assoc()) {
    $productos[] = [
        "id"          => $fila["ID_Producto"],
        "nombre"      => $fila["Nombre_producto"],
        "descripcion" => $fila["Descripcion"],
        "categoria"   => $fila["Categoria"],
        "precio"      => number_format((float)$fila["Precio"], 0, ",", "."),
        "precio_raw"  => (float)$fila["Precio"],
        "stock"       => (int)$fila["Stock"],
        "disponible"  => (int)$fila["Stock"] > 0
    ];
}

echo json_encode(["exito" => true, "productos" => $productos]);

$conexion->close();
?>
