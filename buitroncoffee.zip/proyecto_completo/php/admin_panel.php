<?php
// ============================================================
//  BUITRON COFFEE — Panel Administrador (completo)
//  Archivo: php/admin_panel.php
// ============================================================

session_start();
header("Content-Type: application/json");
require_once "conexion.php";

if (!isset($_SESSION["rol"]) || $_SESSION["rol"] !== "Admin") {
    echo json_encode(["exito" => false, "mensaje" => "Acceso denegado. Solo administradores"]);
    exit;
}

$accion = $_GET["accion"] ?? $_POST["accion"] ?? "productos";

switch ($accion) {

    case "productos":
        $res = $conexion->query("SELECT ID_Producto, Nombre_producto, Descripcion, Categoria, Precio, Stock FROM producto ORDER BY ID_Producto");
        $data = [];
        while ($f = $res->fetch_assoc()) $data[] = $f;
        echo json_encode(["exito" => true, "datos" => $data]);
        break;

    case "usuarios":
        $res = $conexion->query("SELECT u.ID_Usuario, u.Nombre_usuario, u.Apellido, u.Correo, u.Documento, u.Telefono, r.Tipo_rol, IFNULL(u.Activo, 1) AS Activo FROM usuario u INNER JOIN rol r ON u.ID_Rol = r.ID_Rol ORDER BY u.ID_Usuario");
        $data = [];
        while ($f = $res->fetch_assoc()) $data[] = $f;
        echo json_encode(["exito" => true, "datos" => $data]);
        break;

    case "ver_usuario":
        $id = intval($_GET["id"] ?? 0);
        $stmt = $conexion->prepare("SELECT u.ID_Usuario, u.Nombre_usuario, u.Apellido, u.Correo, u.Documento, u.Telefono, r.Tipo_rol, IFNULL(u.Activo, 1) AS Activo, COUNT(p.ID_Pedido) AS Total_pedidos FROM usuario u INNER JOIN rol r ON u.ID_Rol = r.ID_Rol LEFT JOIN pedido p ON p.ID_Usuario = u.ID_Usuario WHERE u.ID_Usuario = ? GROUP BY u.ID_Usuario");
        $stmt->bind_param("i", $id); $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc(); $stmt->close();
        echo json_encode($user ? ["exito" => true, "usuario" => $user] : ["exito" => false, "mensaje" => "No encontrado"]);
        break;

    case "toggle_usuario":
        $id = intval($_POST["id"] ?? 0); $activo = intval($_POST["activo"] ?? 0);
        $stmt = $conexion->prepare("UPDATE usuario SET Activo = ? WHERE ID_Usuario = ? AND ID_Rol != 1");
        $stmt->bind_param("ii", $activo, $id); $ok = $stmt->execute(); $stmt->close();
        echo json_encode(["exito" => $ok, "mensaje" => $ok ? ($activo ? "Usuario habilitado" : "Usuario inhabilitado") : "Error"]);
        break;

    case "pedidos":
        $res = $conexion->query("SELECT p.ID_Pedido, u.Nombre_usuario, u.Apellido, pr.Nombre_producto, dp.Cantidad, dp.Resena, p.Fecha_pedido, (pr.Precio * dp.Cantidad) AS Total FROM pedido p INNER JOIN usuario u ON p.ID_Usuario = u.ID_Usuario INNER JOIN detalle_pedido dp ON p.ID_Pedido = dp.ID_Pedido INNER JOIN producto pr ON dp.ID_Producto = pr.ID_Producto ORDER BY p.Fecha_pedido DESC");
        $data = [];
        while ($f = $res->fetch_assoc()) { $f["Total_fmt"] = "$ " . number_format((float)$f["Total"], 0, ",", "."); $data[] = $f; }
        echo json_encode(["exito" => true, "datos" => $data]);
        break;

    case "devoluciones":
        $res = $conexion->query("SELECT d.ID_Devolucion, u.Nombre_usuario, pr.Nombre_producto, dd.Reembolso, dd.Estado, d.Fecha_devolucion FROM devolucion d INNER JOIN detalle_devolucion dd ON d.ID_Devolucion = dd.ID_Devolucion INNER JOIN detalle_pedido dp ON dd.ID_Detalle_Pedido = dp.ID_Detalle_Pedido INNER JOIN pedido p ON d.ID_Pedido = p.ID_Pedido INNER JOIN usuario u ON p.ID_Usuario = u.ID_Usuario INNER JOIN producto pr ON dp.ID_Producto = pr.ID_Producto ORDER BY d.Fecha_devolucion DESC");
        $data = [];
        while ($f = $res->fetch_assoc()) $data[] = $f;
        echo json_encode(["exito" => true, "datos" => $data]);
        break;

    case "agregar_producto":
        $nombre = trim($_POST["nombre"] ?? ""); $descripcion = trim($_POST["descripcion"] ?? ""); $categoria = trim($_POST["categoria"] ?? ""); $precio = floatval($_POST["precio"] ?? 0); $stock = intval($_POST["stock"] ?? 0);
        if (empty($nombre) || $precio <= 0) { echo json_encode(["exito" => false, "mensaje" => "Nombre y precio obligatorios"]); break; }
        $stmt = $conexion->prepare("INSERT INTO producto (Nombre_producto, Descripcion, Categoria, Precio, Stock) VALUES (?,?,?,?,?)");
        $stmt->bind_param("sssdi", $nombre, $descripcion, $categoria, $precio, $stock); $ok = $stmt->execute(); $stmt->close();
        echo json_encode(["exito" => $ok, "mensaje" => $ok ? "Producto agregado" : $conexion->error]);
        break;

    case "editar_producto":
        $id = intval($_POST["id"] ?? 0); $nombre = trim($_POST["nombre"] ?? ""); $descripcion = trim($_POST["descripcion"] ?? ""); $categoria = trim($_POST["categoria"] ?? ""); $precio = floatval($_POST["precio"] ?? 0); $stock = intval($_POST["stock"] ?? 0);
        $stmt = $conexion->prepare("UPDATE producto SET Nombre_producto=?, Descripcion=?, Categoria=?, Precio=?, Stock=? WHERE ID_Producto=?");
        $stmt->bind_param("sssdii", $nombre, $descripcion, $categoria, $precio, $stock, $id); $ok = $stmt->execute(); $stmt->close();
        echo json_encode(["exito" => $ok, "mensaje" => $ok ? "Producto actualizado" : $conexion->error]);
        break;

    case "eliminar_producto":
        $id = intval($_GET["id"] ?? $_POST["id"] ?? 0);
        $stmt = $conexion->prepare("DELETE FROM producto WHERE ID_Producto = ?");
        $stmt->bind_param("i", $id); $ok = $stmt->execute(); $stmt->close();
        echo json_encode(["exito" => $ok, "mensaje" => $ok ? "Producto eliminado" : $conexion->error]);
        break;

    default:
        echo json_encode(["exito" => false, "mensaje" => "Accion no reconocida"]);
}
$conexion->close();
?>
