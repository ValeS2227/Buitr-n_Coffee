<?php
// ============================================================
//  BUITRON COFFEE — Cerrar sesión
//  Archivo: php/logout.php
// ============================================================

session_start();
session_destroy();

header("Location: ../inisesi_reg_volini.html");
exit;
?>
