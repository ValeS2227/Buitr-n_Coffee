-- ============================================================
--  BUITRON COFFEE — Base de datos completa
--  Archivo: buitroncoffee_db.sql
--  Ejecutar en phpMyAdmin sobre la BD: buitroncoffee
-- ============================================================

CREATE DATABASE IF NOT EXISTS buitroncoffee
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE buitroncoffee;

-- ── 1. Roles ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rol (
    ID_Rol   INT         NOT NULL AUTO_INCREMENT,
    Tipo_rol VARCHAR(50) NOT NULL,
    PRIMARY KEY (ID_Rol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO rol (ID_Rol, Tipo_rol) VALUES (1, 'Admin'), (2, 'Usuario');

-- ── 2. Usuarios ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usuario (
    ID_Usuario    INT          NOT NULL AUTO_INCREMENT,
    Nombre_usuario VARCHAR(100) NOT NULL,
    Apellido      VARCHAR(100) NOT NULL,
    Correo        VARCHAR(150) NOT NULL UNIQUE,
    Documento     VARCHAR(20)  NOT NULL UNIQUE,
    Telefono      VARCHAR(20)  NULL,
    Clave         VARCHAR(255) NOT NULL,
    ID_Rol        INT          NOT NULL DEFAULT 2,
    Activo        TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (ID_Usuario),
    FOREIGN KEY (ID_Rol) REFERENCES rol(ID_Rol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Usuario administrador por defecto (contraseña: admin123)
INSERT IGNORE INTO usuario
    (Nombre_usuario, Apellido, Correo, Documento, Telefono, Clave, ID_Rol)
VALUES
    ('Administrador', 'Buitron', 'admin@buitroncoffee.com', '1000000000',
     '3001234567', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);
-- Nota: la contraseña hasheada corresponde a 'password'
-- Para cambiarla: UPDATE usuario SET Clave = password_hash('tu_clave', PASSWORD_BCRYPT) WHERE ID_Rol = 1;

-- ── 3. Productos ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS producto (
    ID_Producto     INT            NOT NULL AUTO_INCREMENT,
    Nombre_producto VARCHAR(150)   NOT NULL,
    Descripcion     TEXT           NULL,
    Categoria       VARCHAR(100)   NULL,
    Precio          DECIMAL(10,2)  NOT NULL,
    Stock           INT            NOT NULL DEFAULT 0,
    PRIMARY KEY (ID_Producto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO producto (Nombre_producto, Descripcion, Categoria, Precio, Stock) VALUES
    ('Café Molido Premium',
     'Café colombiano molido con tostado medio, aroma intenso y sabor suave. Ideal para cafetera de goteo o prensa francesa.',
     'Café Molido', 28000, 50),
    ('Café en Grano',
     'Granos de café fresco con tostado medio-alto. Perfectos para moler en casa y disfrutar del aroma recién preparado.',
     'Café en Grano', 32000, 40),
    ('Grano Especial Premium',
     'Café de especialidad con notas achocolatadas y frutales. Tostado artesanal que resalta los mejores atributos del café de Pitalito.',
     'Grano Especial', 38000, 30),
    ('Café por Mayor (5kg)',
     'Presentación de 5 kg para negocios y cafeterías. Tostado personalizable. Precio especial por volumen.',
     'Café por Mayor', 135000, 20);

-- ── 4. Pedidos ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pedido (
    ID_Pedido   INT  NOT NULL AUTO_INCREMENT,
    ID_Usuario  INT  NOT NULL,
    Fecha_pedido DATE NOT NULL,
    PRIMARY KEY (ID_Pedido),
    FOREIGN KEY (ID_Usuario) REFERENCES usuario(ID_Usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── 5. Detalle de Pedido ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS detalle_pedido (
    ID_Detalle_Pedido INT  NOT NULL AUTO_INCREMENT,
    ID_Pedido         INT  NOT NULL,
    ID_Producto       INT  NOT NULL,
    Cantidad          INT  NOT NULL,
    Resena            TEXT NULL,
    PRIMARY KEY (ID_Detalle_Pedido),
    FOREIGN KEY (ID_Pedido)   REFERENCES pedido(ID_Pedido)   ON DELETE CASCADE,
    FOREIGN KEY (ID_Producto) REFERENCES producto(ID_Producto) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── 6. Reseñas ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS resena (
    ID_Resena    INT      NOT NULL AUTO_INCREMENT,
    ID_Producto  INT      NOT NULL,
    ID_Usuario   INT      NULL,
    Calificacion TINYINT  NOT NULL CHECK (Calificacion BETWEEN 1 AND 5),
    Comentario   TEXT     NOT NULL,
    Fecha_resena DATE     NOT NULL,
    PRIMARY KEY (ID_Resena),
    FOREIGN KEY (ID_Producto) REFERENCES producto(ID_Producto) ON DELETE CASCADE,
    FOREIGN KEY (ID_Usuario)  REFERENCES usuario(ID_Usuario)   ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── 7. Devoluciones ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS devolucion (
    ID_Devolucion   INT  NOT NULL AUTO_INCREMENT,
    ID_Pedido       INT  NOT NULL,
    Fecha_devolucion DATE NOT NULL,
    PRIMARY KEY (ID_Devolucion),
    FOREIGN KEY (ID_Pedido) REFERENCES pedido(ID_Pedido) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS detalle_devolucion (
    ID_Detalle_Dev    INT            NOT NULL AUTO_INCREMENT,
    ID_Devolucion     INT            NOT NULL,
    ID_Detalle_Pedido INT            NOT NULL,
    Reembolso         DECIMAL(10,2)  NOT NULL DEFAULT 0,
    Estado            VARCHAR(50)    NOT NULL DEFAULT 'Pendiente',
    PRIMARY KEY (ID_Detalle_Dev),
    FOREIGN KEY (ID_Devolucion)     REFERENCES devolucion(ID_Devolucion)       ON DELETE CASCADE,
    FOREIGN KEY (ID_Detalle_Pedido) REFERENCES detalle_pedido(ID_Detalle_Pedido) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Verificar tablas creadas ─────────────────────────────────
SHOW TABLES;
