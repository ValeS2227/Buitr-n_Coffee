<?php
// ============================================================
//  BUITRON COFFEE — Detalle de un producto
//  Archivo: php/producto_detalle.php
//  Retorna: JSON con datos del producto por ID o Categoría
// ============================================================

header("Content-Type: application/json");
require_once "conexion.php";

$id_producto = intval($_GET["id"]        ?? 0);
$categoria   = trim($_GET["categoria"]   ?? "");

if ($id_producto > 0) {
    $stmt = $conexion->prepare(
        "SELECT ID_Producto, Nombre_producto, Descripcion, Categoria, Precio, Stock
         FROM producto WHERE ID_Producto = ? LIMIT 1"
    );
    $stmt->bind_param("i", $id_producto);
} elseif ($categoria !== "") {
    $stmt = $conexion->prepare(
        "SELECT ID_Producto, Nombre_producto, Descripcion, Categoria, Precio, Stock
         FROM producto WHERE Categoria = ? LIMIT 1"
    );
    $stmt->bind_param("s", $categoria);
} else {
    echo json_encode(["exito" => false, "mensaje" => "Parámetros inválidos"]);
    exit;
}

$stmt->execute();
$fila = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conexion->close();

if (!$fila) {
    echo json_encode(["exito" => false, "mensaje" => "Producto no encontrado"]);
    exit;
}

echo json_encode([
    "exito"    => true,
    "producto" => [
        "id"          => $fila["ID_Producto"],
        "nombre"      => $fila["Nombre_producto"],
        "descripcion" => $fila["Descripcion"],
        "categoria"   => $fila["Categoria"],
        "precio"      => number_format((float)$fila["Precio"], 0, ",", "."),
        "precio_raw"  => (float)$fila["Precio"],
        "stock"       => (int)$fila["Stock"],
        "disponible"  => (int)$fila["Stock"] > 0
    ]
]);
?>
