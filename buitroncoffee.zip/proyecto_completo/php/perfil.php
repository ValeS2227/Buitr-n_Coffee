<?php
// ============================================================
//  BUITRON COFFEE — Perfil de Usuario
//  Archivo: php/perfil.php
//  Acciones: ver | editar_correo | editar_nombre | editar_password | historial
// ============================================================

session_start();
header("Content-Type: application/json");
require_once "conexion.php";

// Debe estar autenticado
if (!isset($_SESSION["id_usuario"])) {
    echo json_encode(["exito" => false, "mensaje" => "No autenticado", "redirect" => "inisesi_reg_volini.html"]);
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
$accion     = $_GET["accion"] ?? $_POST["accion"] ?? "ver";

switch ($accion) {

    // ── Ver datos del perfil ────────────────────────────────
    case "ver":
        $stmt = $conexion->prepare(
            "SELECT u.ID_Usuario, u.Nombre_usuario, u.Apellido, u.Correo, u.Documento, u.Telefono, r.Tipo_rol
             FROM usuario u INNER JOIN rol r ON u.ID_Rol = r.ID_Rol
             WHERE u.ID_Usuario = ?"
        );
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$user) {
            echo json_encode(["exito" => false, "mensaje" => "Usuario no encontrado"]);
            exit;
        }

        unset($user["Clave"]); // No exponer contraseña
        echo json_encode(["exito" => true, "usuario" => $user]);
        break;

    // ── Historial de compras ────────────────────────────────
    case "historial":
        $stmt = $conexion->prepare(
            "SELECT p.ID_Pedido, pr.Nombre_producto, dp.Cantidad,
                    (pr.Precio * dp.Cantidad) AS Total, p.Fecha_pedido
             FROM pedido p
             INNER JOIN detalle_pedido dp ON p.ID_Pedido = dp.ID_Pedido
             INNER JOIN producto pr       ON dp.ID_Producto = pr.ID_Producto
             WHERE p.ID_Usuario = ?
             ORDER BY p.Fecha_pedido DESC
             LIMIT 10"
        );
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $res = $stmt->get_result();
        $historial = [];
        while ($f = $res->fetch_assoc()) {
            $historial[] = [
                "id_pedido" => $f["ID_Pedido"],
                "producto"  => $f["Nombre_producto"],
                "cantidad"  => $f["Cantidad"],
                "total"     => number_format($f["Total"], 0, ",", "."),
                "fecha"     => date("d/m/Y", strtotime($f["Fecha_pedido"]))
            ];
        }
        $stmt->close();
        echo json_encode(["exito" => true, "historial" => $historial]);
        break;

    // ── Editar correo ───────────────────────────────────────
    case "editar_correo":
        $nuevo_correo = trim($_POST["correo"] ?? "");
        if (!filter_var($nuevo_correo, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(["exito" => false, "mensaje" => "Correo inválido"]);
            exit;
        }
        $stmt = $conexion->prepare("UPDATE usuario SET Correo = ? WHERE ID_Usuario = ?");
        $stmt->bind_param("si", $nuevo_correo, $id_usuario);
        $ok = $stmt->execute();
        $stmt->close();
        echo json_encode(["exito" => $ok, "mensaje" => $ok ? "Correo actualizado correctamente" : "Error al actualizar"]);
        break;

    // ── Editar nombre de usuario ────────────────────────────
    case "editar_nombre":
        $nombre_nuevo  = trim($_POST["nombre_nuevo"]  ?? "");
        $nombre_actual = trim($_POST["nombre_actual"] ?? "");

        if (empty($nombre_nuevo) || strlen($nombre_nuevo) < 3) {
            echo json_encode(["exito" => false, "mensaje" => "El nombre debe tener al menos 3 caracteres"]);
            exit;
        }

        // Verificar nombre actual
        $chk = $conexion->prepare("SELECT Nombre_usuario FROM usuario WHERE ID_Usuario = ?");
        $chk->bind_param("i", $id_usuario);
        $chk->execute();
        $u = $chk->get_result()->fetch_assoc();
        $chk->close();

        if (!$u || $u["Nombre_usuario"] !== $nombre_actual) {
            echo json_encode(["exito" => false, "mensaje" => "Nombre actual incorrecto"]);
            exit;
        }

        // Verificar que el nuevo nombre no esté tomado
        $chk2 = $conexion->prepare("SELECT ID_Usuario FROM usuario WHERE Nombre_usuario = ? AND ID_Usuario != ?");
        $chk2->bind_param("si", $nombre_nuevo, $id_usuario);
        $chk2->execute();
        $chk2->store_result();
        if ($chk2->num_rows > 0) {
            $chk2->close();
            echo json_encode(["exito" => false, "mensaje" => "Ese nombre de usuario ya está en uso"]);
            exit;
        }
        $chk2->close();

        $stmt = $conexion->prepare("UPDATE usuario SET Nombre_usuario = ? WHERE ID_Usuario = ?");
        $stmt->bind_param("si", $nombre_nuevo, $id_usuario);
        $ok = $stmt->execute();
        $stmt->close();

        if ($ok) {
            $_SESSION["nombre_usuario"] = $nombre_nuevo;
            echo json_encode(["exito" => true, "mensaje" => "Nombre actualizado", "nuevo_nombre" => $nombre_nuevo]);
        } else {
            echo json_encode(["exito" => false, "mensaje" => "Error al actualizar"]);
        }
        break;

    // ── Editar contraseña ───────────────────────────────────
    case "editar_password":
        $actual  = trim($_POST["contrasena_actual"]  ?? "");
        $nueva   = trim($_POST["contrasena_nueva"]   ?? "");
        $repetir = trim($_POST["contrasena_repetir"] ?? "");

        if (empty($actual) || empty($nueva) || empty($repetir)) {
            echo json_encode(["exito" => false, "mensaje" => "Completa todos los campos"]);
            exit;
        }

        if ($nueva !== $repetir) {
            echo json_encode(["exito" => false, "mensaje" => "Las contraseñas nuevas no coinciden"]);
            exit;
        }

        if (strlen($nueva) < 6) {
            echo json_encode(["exito" => false, "mensaje" => "La nueva contraseña debe tener mínimo 6 caracteres"]);
            exit;
        }

        // Verificar contraseña actual
        $stmt = $conexion->prepare("SELECT Clave FROM usuario WHERE ID_Usuario = ?");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $valido = password_verify($actual, $u["Clave"]) || ($actual === $u["Clave"]);
        if (!$valido) {
            echo json_encode(["exito" => false, "mensaje" => "La contraseña actual es incorrecta"]);
            exit;
        }

        $nueva_enc = password_hash($nueva, PASSWORD_BCRYPT);
        $upd = $conexion->prepare("UPDATE usuario SET Clave = ? WHERE ID_Usuario = ?");
        $upd->bind_param("si", $nueva_enc, $id_usuario);
        $ok = $upd->execute();
        $upd->close();

        echo json_encode(["exito" => $ok, "mensaje" => $ok ? "Contraseña actualizada correctamente" : "Error al actualizar"]);
        break;

    default:
        echo json_encode(["exito" => false, "mensaje" => "Acción no reconocida"]);
}

$conexion->close();
?>
