# ☕ Buitron Coffee — Guía de instalación

## 📁 Estructura del proyecto

```
buitroncoffee/
├── 📄 Páginas públicas
│   ├── Buitron_Coffee.html       → Página principal (catálogo)
│   ├── Produccion.html           → Proceso de producción
│   ├── Nosotros.html             → Sobre la empresa
│   ├── Exportaciones.html        → Exportaciones
│   └── Contacto.html             → Formulario de contacto
│
├── 📄 Páginas de producto (detalle + reseñas)
│   ├── cafe-molido.html          → Café Molido Premium
│   ├── grano.html                → Café en Grano
│   ├── grano-especial.html       → Grano Especial Premium
│   └── por-mayor.html            → Café por Mayor (5kg)
│
├── 🔐 Autenticación
│   ├── inisesi_reg_volini.html   → Inicio de sesión / Bienvenida
│   ├── Registro.html             → Registro de usuario
│   └── Recuperar_Contrasena.html → Recuperar contraseña
│
├── 👤 Usuario
│   ├── Perfil.html               → Ver y editar perfil
│   ├── Carrito.html              → Carrito de compras
│   └── Recibo.html               → Recibo/factura de compra
│
├── ⚙️ Administración
│   └── Administrador.html        → Panel completo (productos, usuarios, pedidos)
│
├── 📂 php/                       → Backend PHP
│   ├── conexion.php              → Conexión a MySQL
│   ├── login.php                 → Iniciar sesión
│   ├── logout.php                → Cerrar sesión
│   ├── registro.php              → Registrar usuario
│   ├── productos.php             → Listar productos (API)
│   ├── producto_detalle.php      → Detalle de un producto
│   ├── pedido.php                → Crear pedido directo
│   ├── carrito.php               → Gestión del carrito (sesión)
│   ├── resenas.php               → Reseñas de productos
│   ├── perfil.php                → Perfil de usuario
│   ├── recibo.php                → Recibo de pedido
│   └── admin_panel.php           → Panel administrador
│
├── 📂 estilos/
│   └── Index.css                 → Todos los estilos del proyecto
│
├── 📂 img/                       → Imágenes (copiar del proyecto original)
│
└── 🗄️ buitroncoffee_db.sql       → Base de datos completa
```

---

## 🚀 Instalación paso a paso

### 1. Instalar XAMPP
Descargar e instalar XAMPP desde https://www.apachefriends.org/

### 2. Copiar el proyecto
Copiar la carpeta `buitroncoffee` dentro de:
```
C:\xampp\htdocs\buitroncoffee\
```

### 3. Crear la base de datos
1. Abrir XAMPP → iniciar **Apache** y **MySQL**
2. Ir a http://localhost/phpmyadmin
3. Hacer clic en **"Nueva"** (crear BD llamada `buitroncoffee`)
4. Ir a la pestaña **"Importar"**
5. Seleccionar el archivo **`buitroncoffee_db.sql`**
6. Hacer clic en **"Continuar"**

### 4. Abrir el proyecto
Ir a: http://localhost/buitroncoffee/Buitron_Coffee.html

---

## 🔐 Acceso administrador
- **URL:** http://localhost/buitroncoffee/Administrador.html
- **Usuario:** `Administrador`
- **Contraseña:** `password`

> ⚠️ **Cambiar la contraseña** en phpMyAdmin tras el primer acceso:
> ```sql
> UPDATE usuario SET Clave = 'nueva_clave_hasheada' WHERE ID_Rol = 1;
> ```

---

## 🗂️ Descripción de páginas

| Página | Descripción | Requiere login |
|--------|-------------|----------------|
| Buitron_Coffee.html | Catálogo de productos | No (para comprar sí) |
| cafe-molido.html | Detalle café molido + reseñas | No (para pedir sí) |
| grano.html | Detalle café en grano + reseñas | No |
| grano-especial.html | Detalle grano especial + reseñas | No |
| por-mayor.html | Detalle café por mayor + reseñas | No |
| Carrito.html | Carrito de compras | Sí (para checkout) |
| Recibo.html?id=X | Recibo del pedido X | Sí |
| Perfil.html | Datos y pedidos del usuario | Sí |
| Administrador.html | Panel admin | Solo Admin |

---

## 📋 Funcionalidades implementadas

### Clientes
- ✅ Registro e inicio de sesión
- ✅ Recuperación de contraseña
- ✅ Catálogo de productos desde BD
- ✅ Páginas de detalle por producto
- ✅ Carrito de compras (sesión PHP)
- ✅ Checkout con validación de stock
- ✅ Recibo/factura imprimible (PDF)
- ✅ Reseñas y calificaciones
- ✅ Perfil: ver y editar datos
- ✅ Historial de pedidos
- ✅ Página de contacto

### Administrador
- ✅ Login exclusivo para Admin
- ✅ Gestión de productos (CRUD)
- ✅ Ver y inhabilitar/habilitar usuarios
- ✅ Ver detalles de usuario
- ✅ Listado de pedidos con recibo
- ✅ Listado de devoluciones
