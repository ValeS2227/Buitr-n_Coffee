import './App.css';
import axios from "axios";
import { useState } from "react";

function Registro({ volverLogin }) {

  const [nombre,setNombre] = useState("");
  const [apellido,setApellido] = useState("");
  const [documento,setDocumento] = useState("");
  const [telefono,setTelefono] = useState("");
  const [correo,setCorreo] = useState("");
  const [clave,setClave] = useState("");

  function registrar(e){
    e.preventDefault();

    console.log("Botón presionado");

    const datos = {
      nombre: nombre,
      apellido: apellido,
      correo: correo,
      documento: documento,
      telefono: telefono,
      clave: clave
    };

    console.log("Datos enviados:", datos);

    axios.post("http://localhost:3001/registrar", datos)
    .then((res)=>{
      console.log("Respuesta servidor:", res.data);
      alert("Usuario registrado correctamente");

      // limpiar formulario
      setNombre("");
      setApellido("");
      setDocumento("");
      setTelefono("");
      setCorreo("");
      setClave("");
    })
    .catch((err)=>{
      console.error("Error al registrar:", err);
      alert("Error al registrar usuario");
    });
  }

  return (
    <div className="auth-body">

      <div className="card">
        <h1>Buitrón Coffee</h1>
        <h2>Bienvenido al Registro</h2>

        <form onSubmit={registrar}>

          <label>Nombre usuario</label>
          <input
            type="text"
            placeholder="Ingrese su nombre"
            value={nombre}
            onChange={(e)=>setNombre(e.target.value)}
            required
          />

          <label>Apellido</label>
          <input
            type="text"
            placeholder="Ingrese su apellido"
            value={apellido}
            onChange={(e)=>setApellido(e.target.value)}
            required
          />

          <label>Número de documento</label>
          <input
            type="number"
            placeholder="Ingrese su documento"
            value={documento}
            onChange={(e)=>setDocumento(e.target.value)}
            required
          />

          <label>Número de Teléfono</label>
          <input
            type="tel"
            placeholder="Ingrese número"
            value={telefono}
            onChange={(e)=>setTelefono(e.target.value)}
            required
          />

          <label>Correo Electrónico</label>
          <input
            type="email"
            placeholder="Ingrese correo"
            value={correo}
            onChange={(e)=>setCorreo(e.target.value)}
            required
          />

          <label>Clave</label>
          <input
            type="password"
            placeholder="Ingrese contraseña"
            value={clave}
            onChange={(e)=>setClave(e.target.value)}
            required
          />

          <button type="submit">
            Registrarse
          </button>

          <button
            type="button"
            onClick={volverLogin}
            className="btn-secundario"
          >
            ¿Ya tienes cuenta? Inicia sesión
          </button>

        </form>
      </div>

    </div>
  );
}

export default Registro;