<?php
// ============================================================
//  BUITRON COFFEE — Conexión a la base de datos
//  Archivo: php/conexion.php
//  Tecnología: PHP + MySQLi + XAMPP
// ============================================================

$host     = "localhost";
$usuario  = "root";       // Usuario por defecto en XAMPP
$password = "";           // Contraseña vacía por defecto en XAMPP
$base     = "buitroncoffee";

$conexion = new mysqli($host, $usuario, $password, $base);

// Verificar conexión
if ($conexion->connect_error) {
    die(json_encode([
        "exito"   => false,
        "mensaje" => "Error de conexión: " . $conexion->connect_error
    ]));
}

// Definir charset para soportar tildes y caracteres especiales
$conexion->set_charset("utf8mb4");
?>
