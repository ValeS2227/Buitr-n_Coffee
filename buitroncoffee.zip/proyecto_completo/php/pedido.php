<?php
// ============================================================
//  BUITRON COFFEE — Realizar pedido
//  Archivo: php/pedido.php
// ============================================================

session_start();
header("Content-Type: application/json");
require_once "conexion.php";

// Verificar que el usuario esté autenticado
if (!isset($_SESSION["id_usuario"])) {
    echo json_encode(["exito" => false, "mensaje" => "Debes iniciar sesión para realizar un pedido"]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["exito" => false, "mensaje" => "Método no permitido"]);
    exit;
}

$id_usuario  = $_SESSION["id_usuario"];
$id_producto = intval($_POST["id_producto"] ?? 0);
$cantidad    = intval($_POST["cantidad"]    ?? 0);
$resena      = trim($_POST["resena"]       ?? "");

if ($id_producto <= 0 || $cantidad <= 0) {
    echo json_encode(["exito" => false, "mensaje" => "Datos del pedido inválidos"]);
    exit;
}

// Verificar stock disponible
$stmt = $conexion->prepare("SELECT Stock, Precio FROM producto WHERE ID_Producto = ?");
$stmt->bind_param("i", $id_producto);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$res) {
    echo json_encode(["exito" => false, "mensaje" => "Producto no encontrado"]);
    exit;
}

if ($res["Stock"] < $cantidad) {
    echo json_encode(["exito" => false, "mensaje" => "Stock insuficiente. Solo hay " . $res["Stock"] . " disponibles"]);
    exit;
}

// Iniciar transacción
$conexion->begin_transaction();

try {
    // 1. Crear pedido
    $fecha = date("Y-m-d");
    $stmt = $conexion->prepare("INSERT INTO pedido (ID_Usuario, Fecha_pedido) VALUES (?, ?)");
    $stmt->bind_param("is", $id_usuario, $fecha);
    $stmt->execute();
    $id_pedido = $conexion->insert_id;
    $stmt->close();

    // 2. Crear detalle del pedido
    $stmt = $conexion->prepare("INSERT INTO detalle_pedido (ID_Pedido, ID_Producto, Cantidad, Resena) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $id_pedido, $id_producto, $cantidad, $resena);
    $stmt->execute();
    $stmt->close();

    // 3. Descontar stock
    $stmt = $conexion->prepare("UPDATE producto SET Stock = Stock - ? WHERE ID_Producto = ?");
    $stmt->bind_param("ii", $cantidad, $id_producto);
    $stmt->execute();
    $stmt->close();

    $conexion->commit();

    $total = number_format($res["Precio"] * $cantidad, 0, ",", ".");
    echo json_encode([
        "exito"     => true,
        "mensaje"   => "¡Pedido realizado con éxito!",
        "id_pedido" => $id_pedido,
        "total"     => "$ " . $total
    ]);

} catch (Exception $e) {
    $conexion->rollback();
    echo json_encode(["exito" => false, "mensaje" => "Error al procesar el pedido: " . $e->getMessage()]);
}

$conexion->close();
?>
