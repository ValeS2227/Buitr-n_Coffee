<?php
// ============================================================
//  BUITRON COFFEE — Reseñas de Productos
//  Archivo: php/resenas.php
//  Métodos: GET (obtener) | POST (guardar)
// ============================================================

session_start();
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "conexion.php";

$metodo = $_SERVER["REQUEST_METHOD"];

// ── GET: obtener reseñas de un producto ──────────────────────
if ($metodo === "GET") {
    $id_producto = intval($_GET["id_producto"] ?? 0);

    if ($id_producto <= 0) {
        echo json_encode(["exito" => false, "mensaje" => "ID de producto inválido"]);
        exit;
    }

    $sql = "SELECT r.Calificacion, r.Comentario, r.Fecha_resena,
                   IFNULL(u.Nombre, 'Cliente') AS Nombre
            FROM resena r
            LEFT JOIN usuario u ON r.ID_Usuario = u.ID_Usuario
            WHERE r.ID_Producto = ?
            ORDER BY r.Fecha_resena DESC
            LIMIT 20";

    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_producto);
    $stmt->execute();
    $resultado = $stmt->get_result();

    $resenas = [];
    while ($fila = $resultado->fetch_assoc()) {
        $resenas[] = [
            "calificacion" => (int)$fila["Calificacion"],
            "comentario"   => $fila["Comentario"],
            "autor"        => $fila["Nombre"],
            "fecha"        => date("d/m/Y", strtotime($fila["Fecha_resena"]))
        ];
    }

    $stmt->close();
    $conexion->close();

    echo json_encode(["exito" => true, "resenas" => $resenas]);
    exit;
}

// ── POST: guardar una nueva reseña ───────────────────────────
if ($metodo === "POST") {
    $id_producto  = intval($_POST["id_producto"]  ?? 0);
    $calificacion = intval($_POST["calificacion"] ?? 0);
    $comentario   = trim($_POST["comentario"]     ?? "");

    // El usuario puede estar o no logueado
    $id_usuario = $_SESSION["id_usuario"] ?? null;

    if ($id_producto <= 0 || $calificacion < 1 || $calificacion > 5 || $comentario === "") {
        echo json_encode(["exito" => false, "mensaje" => "Datos incompletos o inválidos"]);
        exit;
    }

    $fecha = date("Y-m-d");

    if ($id_usuario) {
        $stmt = $conexion->prepare(
            "INSERT INTO resena (ID_Producto, ID_Usuario, Calificacion, Comentario, Fecha_resena)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("iiiis", $id_producto, $id_usuario, $calificacion, $comentario, $fecha);
    } else {
        $stmt = $conexion->prepare(
            "INSERT INTO resena (ID_Producto, Calificacion, Comentario, Fecha_resena)
             VALUES (?, ?, ?, ?)"
        );
        $stmt->bind_param("iiis", $id_producto, $calificacion, $comentario, $fecha);
    }

    if ($stmt->execute()) {
        $stmt->close();
        $conexion->close();
        echo json_encode(["exito" => true, "mensaje" => "¡Reseña publicada con éxito!"]);
    } else {
        $stmt->close();
        $conexion->close();
        echo json_encode(["exito" => false, "mensaje" => "Error al guardar la reseña: " . $conexion->error]);
    }
    exit;
}

echo json_encode(["exito" => false, "mensaje" => "Método no permitido"]);
?>
