<?php
// ============================================================
//  BUITRON COFFEE — Carrito de compras (sesión PHP)
//  Archivo: php/carrito.php
//  Acciones: ver | agregar | actualizar | eliminar | vaciar | checkout
// ============================================================

session_start();
header("Content-Type: application/json");
require_once "conexion.php";

$accion = $_GET["accion"] ?? $_POST["accion"] ?? "ver";

// Inicializar carrito en sesión
if (!isset($_SESSION["carrito"])) {
    $_SESSION["carrito"] = [];
}

switch ($accion) {

    // ── Ver carrito ─────────────────────────────────────────
    case "ver":
        $carrito = $_SESSION["carrito"];
        $total   = 0;
        $items   = [];

        foreach ($carrito as $id => $item) {
            $subtotal = $item["precio"] * $item["cantidad"];
            $total   += $subtotal;
            $items[]  = array_merge($item, [
                "id"       => $id,
                "subtotal" => number_format($subtotal, 0, ",", ".")
            ]);
        }

        echo json_encode([
            "exito"  => true,
            "items"  => $items,
            "total"  => number_format($total, 0, ",", "."),
            "total_raw" => $total,
            "cantidad_items" => count($items)
        ]);
        break;

    // ── Agregar al carrito ──────────────────────────────────
    case "agregar":
        $id_producto = intval($_POST["id_producto"] ?? 0);
        $cantidad    = intval($_POST["cantidad"]    ?? 1);

        if ($id_producto <= 0 || $cantidad < 1) {
            echo json_encode(["exito" => false, "mensaje" => "Datos inválidos"]);
            exit;
        }

        // Consultar producto en BD
        $stmt = $conexion->prepare(
            "SELECT ID_Producto, Nombre_producto, Categoria, Precio, Stock FROM producto WHERE ID_Producto = ?"
        );
        $stmt->bind_param("i", $id_producto);
        $stmt->execute();
        $prod = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$prod) {
            echo json_encode(["exito" => false, "mensaje" => "Producto no encontrado"]);
            exit;
        }

        $key = "prod_" . $id_producto;

        // Si ya está en el carrito, sumar cantidad
        if (isset($_SESSION["carrito"][$key])) {
            $nueva_cant = $_SESSION["carrito"][$key]["cantidad"] + $cantidad;
            if ($nueva_cant > $prod["Stock"]) {
                echo json_encode(["exito" => false, "mensaje" => "Stock insuficiente. Máximo: " . $prod["Stock"]]);
                exit;
            }
            $_SESSION["carrito"][$key]["cantidad"] = $nueva_cant;
        } else {
            if ($cantidad > $prod["Stock"]) {
                echo json_encode(["exito" => false, "mensaje" => "Stock insuficiente. Máximo: " . $prod["Stock"]]);
                exit;
            }
            $_SESSION["carrito"][$key] = [
                "id_producto" => $prod["ID_Producto"],
                "nombre"      => $prod["Nombre_producto"],
                "categoria"   => $prod["Categoria"],
                "precio"      => (float)$prod["Precio"],
                "precio_fmt"  => number_format((float)$prod["Precio"], 0, ",", "."),
                "stock"       => (int)$prod["Stock"],
                "cantidad"    => $cantidad
            ];
        }

        echo json_encode([
            "exito"   => true,
            "mensaje" => "¡Producto añadido al carrito!",
            "total_items" => count($_SESSION["carrito"])
        ]);
        break;

    // ── Actualizar cantidad ─────────────────────────────────
    case "actualizar":
        $key      = trim($_POST["key"]      ?? "");
        $cantidad = intval($_POST["cantidad"] ?? 0);

        if (!isset($_SESSION["carrito"][$key])) {
            echo json_encode(["exito" => false, "mensaje" => "Producto no encontrado en carrito"]);
            exit;
        }

        if ($cantidad < 1) {
            unset($_SESSION["carrito"][$key]);
            echo json_encode(["exito" => true, "mensaje" => "Producto eliminado"]);
            exit;
        }

        $stock = $_SESSION["carrito"][$key]["stock"];
        if ($cantidad > $stock) {
            echo json_encode(["exito" => false, "mensaje" => "Stock insuficiente. Máximo: $stock"]);
            exit;
        }

        $_SESSION["carrito"][$key]["cantidad"] = $cantidad;
        echo json_encode(["exito" => true, "mensaje" => "Cantidad actualizada"]);
        break;

    // ── Eliminar un ítem ────────────────────────────────────
    case "eliminar":
        $key = trim($_POST["key"] ?? "");
        if (isset($_SESSION["carrito"][$key])) {
            unset($_SESSION["carrito"][$key]);
            echo json_encode(["exito" => true, "mensaje" => "Producto eliminado del carrito"]);
        } else {
            echo json_encode(["exito" => false, "mensaje" => "Producto no encontrado"]);
        }
        break;

    // ── Vaciar carrito ──────────────────────────────────────
    case "vaciar":
        $_SESSION["carrito"] = [];
        echo json_encode(["exito" => true, "mensaje" => "Carrito vaciado"]);
        break;

    // ── Checkout: crear pedidos por cada ítem ──────────────
    case "checkout":
        if (!isset($_SESSION["id_usuario"])) {
            echo json_encode(["exito" => false, "mensaje" => "Debes iniciar sesión para finalizar la compra"]);
            exit;
        }

        if (empty($_SESSION["carrito"])) {
            echo json_encode(["exito" => false, "mensaje" => "El carrito está vacío"]);
            exit;
        }

        $id_usuario = $_SESSION["id_usuario"];
        $fecha      = date("Y-m-d");
        $pedidos    = [];
        $errores    = [];

        $conexion->begin_transaction();

        try {
            // Crear un pedido agrupado
            $stmt = $conexion->prepare("INSERT INTO pedido (ID_Usuario, Fecha_pedido) VALUES (?, ?)");
            $stmt->bind_param("is", $id_usuario, $fecha);
            $stmt->execute();
            $id_pedido = $conexion->insert_id;
            $stmt->close();

            foreach ($_SESSION["carrito"] as $key => $item) {
                $id_prod  = $item["id_producto"];
                $cantidad = $item["cantidad"];

                // Verificar stock actual
                $chk = $conexion->prepare("SELECT Stock, Precio FROM producto WHERE ID_Producto = ? FOR UPDATE");
                $chk->bind_param("i", $id_prod);
                $chk->execute();
                $pdata = $chk->get_result()->fetch_assoc();
                $chk->close();

                if (!$pdata || $pdata["Stock"] < $cantidad) {
                    throw new Exception("Stock insuficiente para: " . $item["nombre"]);
                }

                // Insertar detalle
                $stmt2 = $conexion->prepare("INSERT INTO detalle_pedido (ID_Pedido, ID_Producto, Cantidad) VALUES (?, ?, ?)");
                $stmt2->bind_param("iii", $id_pedido, $id_prod, $cantidad);
                $stmt2->execute();
                $stmt2->close();

                // Descontar stock
                $upd = $conexion->prepare("UPDATE producto SET Stock = Stock - ? WHERE ID_Producto = ?");
                $upd->bind_param("ii", $cantidad, $id_prod);
                $upd->execute();
                $upd->close();

                $pedidos[] = [
                    "producto"  => $item["nombre"],
                    "cantidad"  => $cantidad,
                    "subtotal"  => number_format($pdata["Precio"] * $cantidad, 0, ",", ".")
                ];
            }

            $conexion->commit();

            // Vaciar carrito tras compra exitosa
            $_SESSION["carrito"] = [];

            echo json_encode([
                "exito"     => true,
                "mensaje"   => "¡Compra realizada con éxito!",
                "id_pedido" => $id_pedido,
                "pedidos"   => $pedidos
            ]);

        } catch (Exception $e) {
            $conexion->rollback();
            echo json_encode(["exito" => false, "mensaje" => $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(["exito" => false, "mensaje" => "Acción no reconocida"]);
}

$conexion->close();
?>
