<?php
// ============================================================
//  BUITRON COFFEE — Recibo de pedido
//  Archivo: php/recibo.php
//  Retorna: JSON con detalles de un pedido específico
// ============================================================

session_start();
header("Content-Type: application/json");
require_once "conexion.php";

if (!isset($_SESSION["id_usuario"])) {
    echo json_encode(["exito" => false, "mensaje" => "No autenticado"]);
    exit;
}

$id_pedido  = intval($_GET["id_pedido"] ?? 0);
$id_usuario = $_SESSION["id_usuario"];

if ($id_pedido <= 0) {
    echo json_encode(["exito" => false, "mensaje" => "ID de pedido inválido"]);
    exit;
}

// Datos del pedido (solo los pedidos del usuario autenticado, o admin ve todos)
$es_admin = ($_SESSION["rol"] ?? "") === "Admin";

if ($es_admin) {
    $stmt = $conexion->prepare(
        "SELECT p.ID_Pedido, p.Fecha_pedido,
                u.Nombre_usuario, u.Apellido, u.Correo, u.Telefono, u.Documento,
                pr.Nombre_producto, pr.Categoria, dp.Cantidad, pr.Precio,
                (pr.Precio * dp.Cantidad) AS Subtotal, dp.Resena
         FROM pedido p
         INNER JOIN usuario u         ON p.ID_Usuario  = u.ID_Usuario
         INNER JOIN detalle_pedido dp ON p.ID_Pedido   = dp.ID_Pedido
         INNER JOIN producto pr       ON dp.ID_Producto = pr.ID_Producto
         WHERE p.ID_Pedido = ?"
    );
    $stmt->bind_param("i", $id_pedido);
} else {
    $stmt = $conexion->prepare(
        "SELECT p.ID_Pedido, p.Fecha_pedido,
                u.Nombre_usuario, u.Apellido, u.Correo, u.Telefono, u.Documento,
                pr.Nombre_producto, pr.Categoria, dp.Cantidad, pr.Precio,
                (pr.Precio * dp.Cantidad) AS Subtotal, dp.Resena
         FROM pedido p
         INNER JOIN usuario u         ON p.ID_Usuario  = u.ID_Usuario
         INNER JOIN detalle_pedido dp ON p.ID_Pedido   = dp.ID_Pedido
         INNER JOIN producto pr       ON dp.ID_Producto = pr.ID_Producto
         WHERE p.ID_Pedido = ? AND p.ID_Usuario = ?"
    );
    $stmt->bind_param("ii", $id_pedido, $id_usuario);
}

$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo json_encode(["exito" => false, "mensaje" => "Pedido no encontrado"]);
    exit;
}

$items  = [];
$total  = 0;
$pedido = null;

while ($f = $res->fetch_assoc()) {
    if (!$pedido) {
        $pedido = [
            "id_pedido"  => $f["ID_Pedido"],
            "fecha"      => date("d/m/Y", strtotime($f["Fecha_pedido"])),
            "cliente"    => $f["Nombre_usuario"] . " " . $f["Apellido"],
            "correo"     => $f["Correo"],
            "telefono"   => $f["Telefono"],
            "documento"  => $f["Documento"]
        ];
    }
    $subtotal = (float)$f["Subtotal"];
    $total   += $subtotal;
    $items[]  = [
        "producto"  => $f["Nombre_producto"],
        "categoria" => $f["Categoria"],
        "cantidad"  => (int)$f["Cantidad"],
        "precio"    => number_format((float)$f["Precio"], 0, ",", "."),
        "subtotal"  => number_format($subtotal, 0, ",", "."),
        "resena"    => $f["Resena"] ?? ""
    ];
}

$stmt->close();
$conexion->close();

echo json_encode([
    "exito"  => true,
    "pedido" => $pedido,
    "items"  => $items,
    "total"  => number_format($total, 0, ",", "."),
    "total_raw" => $total
]);
?>
