<?php
// ============================================================
//  BUITRON COFFEE — Login de usuario
//  Archivo: php/login.php
// ============================================================

session_start();
header("Content-Type: application/json");
require_once "conexion.php";

// Solo aceptar peticiones POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["exito" => false, "mensaje" => "Método no permitido"]);
    exit;
}

$nombre_usuario = trim($_POST["usuario"] ?? "");
$clave          = trim($_POST["password"] ?? "");

if (empty($nombre_usuario) || empty($clave)) {
    echo json_encode(["exito" => false, "mensaje" => "Por favor completa todos los campos"]);
    exit;
}

// Buscar usuario en la BD
$stmt = $conexion->prepare(
    "SELECT u.ID_Usuario, u.Nombre_usuario, u.Apellido, u.Clave, r.Tipo_rol
     FROM usuario u
     INNER JOIN rol r ON u.ID_Rol = r.ID_Rol
     WHERE u.Nombre_usuario = ?"
);
$stmt->bind_param("s", $nombre_usuario);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    echo json_encode(["exito" => false, "mensaje" => "Usuario o contraseña incorrectos"]);
    exit;
}

$usuario = $resultado->fetch_assoc();

// Verificar contraseña con password_verify (para contraseñas encriptadas con bcrypt)
// Si las contraseñas aún no están encriptadas, usa: $clave === $usuario["Clave"]
if (!password_verify($clave, $usuario["Clave"])) {
    // Fallback temporal para contraseñas en texto plano (mientras migras)
    if ($clave !== $usuario["Clave"]) {
        echo json_encode(["exito" => false, "mensaje" => "Usuario o contraseña incorrectos"]);
        exit;
    }
}

// Guardar datos en sesión
$_SESSION["id_usuario"]     = $usuario["ID_Usuario"];
$_SESSION["nombre_usuario"] = $usuario["Nombre_usuario"];
$_SESSION["apellido"]       = $usuario["Apellido"];
$_SESSION["rol"]            = $usuario["Tipo_rol"];

echo json_encode([
    "exito"   => true,
    "mensaje" => "Bienvenido, " . $usuario["Nombre_usuario"],
    "rol"     => $usuario["Tipo_rol"]
]);

$stmt->close();
$conexion->close();
?>
